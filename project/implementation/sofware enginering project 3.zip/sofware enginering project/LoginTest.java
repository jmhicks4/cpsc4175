
import java.io.FileNotFoundException;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LoginTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LoginTest
{
    private PlayerData playerDa1;

    /**
     * Default constructor for test class LoginTest
     */
    public LoginTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        
        playerDa1 = new PlayerData();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    

    @Test
    public void saveAndLoadTest()throws FileNotFoundException
    {
        Login.saveData(playerDa1);
        assertEquals(playerDa1.toString(), Login.loadData("default").toString());
    }

    @Test
    public void newGameTest()throws FileNotFoundException
    {
        assertNotNull(Login.newGame("test1"));
    }
}



