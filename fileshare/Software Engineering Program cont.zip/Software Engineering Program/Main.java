import java.io.FileNotFoundException;
import java.util.Scanner;
public class Main
{
    public static void main(String args[]) throws FileNotFoundException{
        boolean gameRunning = true;
        PlayerData currentPlayer = new PlayerData();
        currentPlayer = Login.menu();
        while(gameRunning == true){
            System.out.println("What would you like to do?");
            System.out.println("1 : Battle");
            System.out.println("2 : Shop");
            System.out.println("3 : Save");
            System.out.println("4 : Quit Game");
            Scanner command = new Scanner(System.in);
            int currentCommand = command.nextInt();
            if(currentCommand == 1){
                Battle battle = new Battle(currentPlayer);
                battle.printBattleField();
                battle.setEnemyTroops();
                battle.printBattleField();
                battle.setPlayerTroops();
                battle.printBattleField();
            }
            if(currentCommand == 2){
                currentPlayer = Shop.shopWindow(currentPlayer);
            }
            if(currentCommand == 3){
                Login.saveData(currentPlayer);
            }
            if(currentCommand == 4){
                gameRunning = false;
            }
        }
    }
}
