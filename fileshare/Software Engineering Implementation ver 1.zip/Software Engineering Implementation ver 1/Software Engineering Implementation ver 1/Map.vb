﻿Public Class Map
    Private Sub TestBattle_Click(sender As Object, e As EventArgs) Handles TestBattle.Click
        BattleTest.Show()
        Me.Hide()
    End Sub
End Class