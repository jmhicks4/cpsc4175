﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BattleTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.UpButton = New System.Windows.Forms.Button()
        Me.DownButton = New System.Windows.Forms.Button()
        Me.LeftButton = New System.Windows.Forms.Button()
        Me.RightButton = New System.Windows.Forms.Button()
        Me.TroopList = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'UpButton
        '
        Me.UpButton.Location = New System.Drawing.Point(1060, 78)
        Me.UpButton.Name = "UpButton"
        Me.UpButton.Size = New System.Drawing.Size(75, 23)
        Me.UpButton.TabIndex = 1
        Me.UpButton.Text = "Up"
        Me.UpButton.UseVisualStyleBackColor = True
        '
        'DownButton
        '
        Me.DownButton.Location = New System.Drawing.Point(1060, 166)
        Me.DownButton.Name = "DownButton"
        Me.DownButton.Size = New System.Drawing.Size(75, 23)
        Me.DownButton.TabIndex = 2
        Me.DownButton.Text = "Down"
        Me.DownButton.UseVisualStyleBackColor = True
        '
        'LeftButton
        '
        Me.LeftButton.Location = New System.Drawing.Point(1017, 123)
        Me.LeftButton.Name = "LeftButton"
        Me.LeftButton.Size = New System.Drawing.Size(75, 23)
        Me.LeftButton.TabIndex = 3
        Me.LeftButton.Text = "Left"
        Me.LeftButton.UseVisualStyleBackColor = True
        '
        'RightButton
        '
        Me.RightButton.Location = New System.Drawing.Point(1098, 123)
        Me.RightButton.Name = "RightButton"
        Me.RightButton.Size = New System.Drawing.Size(75, 23)
        Me.RightButton.TabIndex = 4
        Me.RightButton.Text = "Right"
        Me.RightButton.UseVisualStyleBackColor = True
        '
        'TroopList
        '
        Me.TroopList.FormattingEnabled = True
        Me.TroopList.Location = New System.Drawing.Point(1038, 242)
        Me.TroopList.Name = "TroopList"
        Me.TroopList.Size = New System.Drawing.Size(121, 21)
        Me.TroopList.TabIndex = 5
        '
        'BattleTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(1184, 961)
        Me.Controls.Add(Me.TroopList)
        Me.Controls.Add(Me.RightButton)
        Me.Controls.Add(Me.LeftButton)
        Me.Controls.Add(Me.DownButton)
        Me.Controls.Add(Me.UpButton)
        Me.Name = "BattleTest"
        Me.Text = "BattleTest"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UpButton As Button
    Friend WithEvents DownButton As Button
    Friend WithEvents LeftButton As Button
    Friend WithEvents RightButton As Button
    Friend WithEvents TroopList As ComboBox
End Class
