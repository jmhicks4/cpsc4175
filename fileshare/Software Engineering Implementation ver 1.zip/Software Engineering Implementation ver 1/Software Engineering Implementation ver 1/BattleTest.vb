﻿Public Class BattleTest
    Dim CurrentSoldier As String
    Private Sub BattleTest_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PopulateBox()
        LoadTroops()
    End Sub
    Private Sub BattleTest_Paint(ByVal sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        Dim pen As New Pen(Color.Black)
        For index As Integer = 100 To 1000 Step 100
            e.Graphics.DrawLine(pen, index, 0, index, 1000)
            e.Graphics.DrawLine(pen, 0, index, 1000, index)
        Next
    End Sub
    Private Sub PopulateBox()
        For index As Integer = 1 To 5
            TroopList.Items.Add("Soldier" + Convert.ToString(index))
        Next
    End Sub
    Private Sub LoadTroops()
        For index As Integer = 1 To 5
            Dim picBox As New PictureBox
            picBox.Image = My.Resources.roman_soldier
            picBox.Height = 100
            picBox.Width = 100
            picBox.SizeMode = PictureBoxSizeMode.StretchImage
            picBox.Location = New Point(index * 100, 900)
            picBox.Visible = True
            Controls.Add(picBox)
            picBox.Name = "Soldier" + Convert.ToString(index)
        Next
    End Sub

    Private Sub UpButton_Click(sender As Object, e As EventArgs) Handles UpButton.Click
        If TroopList.SelectedIndex <> 0 Then
        End If
    End Sub

    Private Sub LeftButton_Click(sender As Object, e As EventArgs) Handles LeftButton.Click

    End Sub

    Private Sub DownButton_Click(sender As Object, e As EventArgs) Handles DownButton.Click

    End Sub

    Private Sub RightButton_Click(sender As Object, e As EventArgs) Handles RightButton.Click

    End Sub
End Class
