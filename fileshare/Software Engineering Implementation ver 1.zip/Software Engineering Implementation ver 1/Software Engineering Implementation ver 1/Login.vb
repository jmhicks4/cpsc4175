﻿Public Class Login
    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click
        Map.Show()
        Me.Hide()
    End Sub
End Class
