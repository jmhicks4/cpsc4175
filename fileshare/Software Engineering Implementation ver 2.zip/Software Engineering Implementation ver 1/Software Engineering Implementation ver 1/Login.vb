﻿Imports System
Imports System.IO
Imports System.Text
Public Class Login
    Dim saveFile As String = "saves.Text"
    Dim playerCharacters As New Player
    Dim duplicate As Boolean = False
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Reader As System.IO.StreamReader
        Reader = My.Computer.FileSystem.OpenTextFileReader(saveFile)
        Do While Reader.Peek() > -1
            SaveFiles.Items.Add(Reader.ReadLine())
            For index As Integer = 1 To 6
                Reader.ReadLine()
            Next
        Loop
        Reader.Close()
    End Sub
    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click
        If SaveFiles.SelectedIndex <> 0 Then
            Dim contentReader As System.IO.StreamReader
            contentReader = My.Computer.FileSystem.OpenTextFileReader(SaveFiles.SelectedValue + ".Text")
            playerCharacters.SetMoney(Integer.Parse(contentReader.ReadLine()))
            playerCharacters.SetLevel(Integer.Parse(contentReader.ReadLine()))
            playerCharacters.AddTroops(contentReader.ReadLine())
            playerCharacters.AddTroops(contentReader.ReadLine())
            playerCharacters.AddTroops(contentReader.ReadLine())
            playerCharacters.AddTroops(contentReader.ReadLine())
            Map.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub NewGameButton_Click(sender As Object, e As EventArgs) Handles NewGameButton.Click
        Console.Write(SaveFiles.Items.Count)
        If SaveFiles.Items.Count > 0 Then
            For index As Integer = 0 To SaveFiles.Items.Count - 1
                If SaveFiles.Items.Item(index) = NewGameTxt.Text Then
                    duplicate = True
                End If
            Next
        End If
        If duplicate = False Then
            Dim saveWriter As System.IO.StreamWriter
            saveWriter = My.Computer.FileSystem.OpenTextFileWriter(saveFile, True)
            saveWriter.WriteLine(NewGameTxt.Text)
            saveWriter.Close()
            Dim contentWriter As System.IO.StreamWriter
            contentWriter = My.Computer.FileSystem.OpenTextFileWriter(NewGameTxt.Text + ".Text", True)
            contentWriter.WriteLine("100")
            contentWriter.WriteLine("1")
            contentWriter.WriteLine("roman soldier")
            contentWriter.WriteLine("roman soldier")
            contentWriter.WriteLine("roman javelin")
            contentWriter.WriteLine("roman javelin")
            contentWriter.Close()
        End If
        duplicate = False
    End Sub
End Class
