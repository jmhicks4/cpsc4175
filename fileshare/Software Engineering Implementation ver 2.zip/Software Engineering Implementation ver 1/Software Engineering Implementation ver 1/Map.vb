﻿Public Class Map
    Private Sub TestBattle_Click(sender As Object, e As EventArgs) Handles TestBattle.Click
        BattleTest.Show()
        Me.Hide()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class