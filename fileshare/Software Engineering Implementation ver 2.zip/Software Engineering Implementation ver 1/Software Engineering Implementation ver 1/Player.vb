﻿Public Class Player
    Dim money As Integer
    Dim level As Integer
    Dim troops = {}

    Public Function SetMoney(ByVal newMoney As Integer)
        money = newMoney
    End Function
    Public Function GetMoney() As Integer
        Return money
    End Function
    Public Function SetLevel(ByVal newLevel As Integer)
        level = newLevel
    End Function
    Public Function GetLevel() As Integer
        Return level
    End Function
    Public Function AddTroops(ByVal newTroop As String)
        troops.Add(newTroop)
    End Function
    Public Function print() As String
        Return money + "/n" + level + "/n" + troops(0) + "/n" + troops(1) + "/n" + troops(2) + "/n" + troops(3)
    End Function
End Class
