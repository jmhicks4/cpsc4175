﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LoginButton = New System.Windows.Forms.Button()
        Me.SaveFiles = New System.Windows.Forms.ComboBox()
        Me.NewGameButton = New System.Windows.Forms.Button()
        Me.NewGameTxt = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'LoginButton
        '
        Me.LoginButton.Location = New System.Drawing.Point(207, 145)
        Me.LoginButton.Name = "LoginButton"
        Me.LoginButton.Size = New System.Drawing.Size(75, 23)
        Me.LoginButton.TabIndex = 0
        Me.LoginButton.Text = "Login"
        Me.LoginButton.UseVisualStyleBackColor = True
        '
        'SaveFiles
        '
        Me.SaveFiles.FormattingEnabled = True
        Me.SaveFiles.Location = New System.Drawing.Point(185, 102)
        Me.SaveFiles.Name = "SaveFiles"
        Me.SaveFiles.Size = New System.Drawing.Size(121, 21)
        Me.SaveFiles.TabIndex = 1
        Me.SaveFiles.Text = "Choose A Save File"
        '
        'NewGameButton
        '
        Me.NewGameButton.Location = New System.Drawing.Point(207, 242)
        Me.NewGameButton.Name = "NewGameButton"
        Me.NewGameButton.Size = New System.Drawing.Size(75, 23)
        Me.NewGameButton.TabIndex = 2
        Me.NewGameButton.Text = "New Game"
        Me.NewGameButton.UseVisualStyleBackColor = True
        '
        'NewGameTxt
        '
        Me.NewGameTxt.Location = New System.Drawing.Point(196, 201)
        Me.NewGameTxt.Name = "NewGameTxt"
        Me.NewGameTxt.Size = New System.Drawing.Size(100, 20)
        Me.NewGameTxt.TabIndex = 3
        '
        'Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 523)
        Me.Controls.Add(Me.NewGameTxt)
        Me.Controls.Add(Me.NewGameButton)
        Me.Controls.Add(Me.SaveFiles)
        Me.Controls.Add(Me.LoginButton)
        Me.Name = "Login"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LoginButton As Button
    Friend WithEvents SaveFiles As ComboBox
    Friend WithEvents NewGameButton As Button
    Friend WithEvents NewGameTxt As TextBox
End Class
