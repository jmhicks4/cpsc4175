﻿Public Class Troop
    Dim troopName As String
    Dim troopX As Integer
    Dim troopY As Integer
End Class